<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cadastro;

class CadastrosController extends Controller
{
    public function create(){
	return view('cadastros.create');
    }
     
    public function store(Request $request){
	Cadastro::create([
		'nome' => $request->nome,
		'idade' => $request->idade,
		'email' => $request->email,
		'auxilio' => $request->auxilio,
		'problema' => $request->problema,
	]);
	return "Cadastro realizado com sucesso!";
    }
}
